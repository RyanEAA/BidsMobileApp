//
//  PopUps.swift
//  Bids
//
//  Created by Ryan Aparicio on 10/3/24.
//

import Foundation
import UIKit

extension VCBidsGame {
    func popUp(Title: String, Message: String ){
        let alertController = UIAlertController(title: Title, message: Message, preferredStyle: .alert)

        let okAction = UIAlertAction(title: "Restart", style: .default) { _ in
            print("Restart tapped")
            // going to restart state
            self.setupGame()
        }

        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func cardsRanOut() {
        let alertController = UIAlertController(title: "Popup Title", message: "This is the message in the popup.", preferredStyle: .alert)

        let okAction = UIAlertAction(title: "Restart", style: .default) { _ in
            print("Restart tapped")
            // going to restart state
            self.setupGame()
        }

        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func PlayerWon(){
        print("\nPop Up Screen: Player Won")
        let alertController = UIAlertController(title: "YOU WON!", message: "Final Score\nPlayer:\(player_money)\nComp:\(comp_money)", preferredStyle: .alert)

        let okAction = UIAlertAction(title: "Restart", style: .default) { _ in
            print("Restart tapped")
            // going to restart state
            self.setupGame()
            self.updateLbls()
        }

        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func CompWon(){
        print("\nPop Up Screen: Comp Won")
        let alertController = UIAlertController(title: "COMP WON!", message: "Final Score\nPlayer:\(player_money)\nComp:\(comp_money)", preferredStyle: .alert)

        let okAction = UIAlertAction(title: "Restart", style: .default) { _ in
            print("restart tapped")
            // going to restart state
            self.setupGame()
            self.updateLbls()
            
        }

        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    // Function to check player's money state
    func checkPlayersMoney() {
        
        if player_money <= 0{
            print("Player has no money: \(player_money)")
            
            popUp(Title: "YOU LOST", Message: "TRY AGAIN!")
        }
        if comp_money <= 0{
            print("Comp has no money: \(player_money)")
            popUp(Title: "YOU WON", Message: "Congratulations")
        }
        
    }
    

    
    func setupGame(){
        print("\nGAME RESTARTED")
        
        next_turn = 0
        player_completed_move = false
        player_money = 15
        comp_money = 15
        // Enable user interaction on the UIImageView
        imgDeck.isUserInteractionEnabled = true
        
        // Create a tap gesture recognizer
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        
        // Add the gesture recognizer to the UIImageView
        imgDeck.addGestureRecognizer(tapGestureRecognizer)
        
        // restarts the image of cards
        restartHandCardImages()
        
        //grey out button options
        lowerAllButtonOpacity()
        
        // lower bid buttons
        lowerBidOpacity()
        
        cards_img_value_house = generateCardValues()
                
        print("Starting number of cards: \(cards_img_value_house.count)")
        print("Starting player money amount: \(player_money)")
        print("Starting comp money amount: \(comp_money)")
        
    }
}

