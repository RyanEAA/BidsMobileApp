//
//  UserOptions.swift
//  Bids
//
//  Created by Ryan Aparicio on 10/3/24.
//

import Foundation
import UIKit

extension VCBidsGame {
    // pick card function
    func pickCard() -> Card{
        // Generate a random index
        let randomIndex = Int.random(in: 0..<cards_img_value_house.count)
        
        // Get the card at the random index
        let picked_card = cards_img_value_house[randomIndex]
                
        // Remove the card from the list
        cards_img_value_house.remove(at: randomIndex)
        print("number of cards left \(cards_img_value_house.count)")
        
        return picked_card
    }
    // means that player is going to match what opponent put
    func call(player: Int){
        // if it's the player's turn
        if player == 0 {
            // see if comp bid in the game
            if comp_move.move == "bid"{
                // then we know we can call or bid
                
                //check comp put more money in than we have then we return the excess and we continue
                if comp_move.amount > player_money{
                    var calc_return = comp_move.amount - player_money
                    comp_money += calc_return
                    player_move = (move: "bid", amount: comp_move.amount)
                    print("returned comp money")
                } else {
                    // call is a bid
                    bid(player: 0, amount: comp_move.amount)
                }
            }
        } else {
            // computers turn
            if player_move.move == "bid"{
                // then we know we can call or bid
                
                //check comp put more money in than we have then we return the excess and we continue
                if player_move.amount > comp_money{
                    var calc_return = player_move.amount - comp_money
                    player_money += calc_return
                    player_move = (move: "bid", amount: comp_move.amount)
                    print("returned player money")
                } else {
                    // call is a bid
                    bid(player: 1, amount: comp_move.amount)
                    
                }
        }

    }
        

    }
    
    func fold(player: Int){
        // person folded
        if player == 0 {
            comp_money += pot_money
            pot_money = 0
        }
        // comp folded
        if player == 1 {
            player_money += pot_money
            pot_money = 0
        }
        
        // get rid of cards in hand
        print("moving to next player from fold")
        playOver = true
    }
    
    func pass(player: Int){
        //if it's the player's turn and the computer passes then it's the end of the turn
        if player == 0 {
            print("\nPlayer 0 passed. Printed from pass()")
            
            // this means that comp passed and we passed
            if comp_move.move == "pass"{
                // we check who wins
                print("both players passed moving on")
                playOver = true
                    
                } else {
                    player_move = (move: "pass", amount: 0)
                }
            
            player_completed_move = true
            
            }  else { // it comps move
                print("\nPlayer 1 passed. Printed from pass()")
                // check if player passed
                if player_move.move == "pass"{
                    // we check who win
                    print("both players passed moving on")
                    playOver = true
                } else {
                    comp_move = (move: "pass", amount: 0)
                }
            
            }
        print("moving to next player from pass")
        nextPlayer()
        updateLbls()
        }
    
    func bid(player: Int, amount: Int){
        // player 0 is person
        if player == 0 {
            pot_money += amount
            player_money -= amount
            
            // check if amount = 0
            if amount == 0 {
                pass(player: player)
            }
            // check if player went all in
            // check if next turn is player
            else if player_money == 0{
                // check who won
                print("player went all in")
                playOver = true
            }
            else {
                player_move = (move:"bid", amount: amount)
            }
            player_completed_move = true
        }
        //it's the computer turns
        if player == 1 {
            pot_money += amount
            comp_money -= amount
            if amount == 0 {
                print("computer passes")
                pass(player: player)
            }
            else if comp_money == 0 {
                print("computer went all in")
                // player went all in check pot
                playOver = true
            }else{
                comp_move = (move:"bid", amount: amount)
            }
            
        }

        print("moving to next player from bid")
        nextPlayer()
        updateLbls()

    }
    
    func payCostOfPlaying(){
        player_money -= 1
//        lblMyMoney.text = ("Money: \(player_money)")
        
        comp_money -= 1
//        lblOppMoney.text = ("Money: \(comp_money)")
        
        pot_money += 2
//        lblPotMoney.text = "Pot: \(pot_money)"
        updateLbls()
    }
    
    func checkWin(){
        //revealCards()
        // check who has highest card
        // if player card higher than comp
        

        if player_card.value.1 > comp_card.value.1{
            // player wins and gets pot money
            playerSmallWin()


        }
        else if comp_card.value.1 > player_card.value.1 {
            compSmallWin()


        } else {
            // we have to check house
            if player_card.house.1 > comp_card.house.1{
                // player wins and gets pot money
                playerSmallWin()


            }
            else if comp_card.house.1 > player_card.house.1 {
                compSmallWin()
            }
        }

        // reseting player and comp moves
        player_move = (move: "", amount: 0)
        comp_move = (move: "", amount: 0)
        restartHandCardImages()
        lowerAllButtonOpacity()

    }
    
    func playerSmallWin(){
        print("\nplayer won")
        player_money += pot_money
        pot_money = 0
    }
    
    func compSmallWin(){
        print("\ncomp won")
        comp_money += pot_money
        pot_money = 0
    }
}
