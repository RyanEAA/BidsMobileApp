//
//  OpacityFunction.swift
//  Bids
//
//  Created by Ryan Aparicio on 10/3/24.
//

import Foundation

extension VCBidsGame {
    
    func increaseAllButtonOpacity(){
        btnBidDisplay.alpha = 1.0
        btnFoldDisplay.alpha = 1.0
        btnPassDisplay.alpha = 1.0
    }
    
    func lowerAllButtonOpacity(){
        btnBidDisplay.alpha = 0.5
        btnFoldDisplay.alpha = 0.5
        btnPassDisplay.alpha = 0.5
    }
    
    func increaseBidOpacity(){
        sldrBidAmount.alpha = 1.0
        lblBidAmount.alpha = 1.0
        self.btnBidConfirmOpaq.alpha = 1.0
    }
    
    func lowerBidOpacity(){
        sldrBidAmount.alpha = 0.0
        lblBidAmount.alpha = 0.0
        self.btnBidConfirmOpaq.alpha = 0.0
    }
}
