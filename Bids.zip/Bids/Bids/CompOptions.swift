//
//  CompOptions.swift
//  Bids
//
//  Created by Ryan Aparicio on 10/3/24.
//

import Foundation
import UIKit

extension VCBidsGame {
    func compPicksCard() -> Card{
        // Generate a random index
        let random_index = Int.random(in: 0..<cards_img_value_house.count-1)
        
        // Get the card at the random index
        let picked_card = cards_img_value_house[random_index]
        
        //remove card from index
        cards_img_value_house.remove(at: random_index)
        
        imgCompCard.image = UIImage(named: "board")
        print("number of cards left \(cards_img_value_house.count)")
        return picked_card
        
    }
    
    func compMove(){
        player_completed_move = false
        var player_num = 1
        var actions = ["bid", "fold"]
        
        print("player move was: \(player_move.move)")
        // action is what the comp chooses
        var action = actions.randomElement()
        
        if action == "bid" || player_move.move == "pass"{
            var amount_max = comp_money
            var amount_min = player_move.amount
            
            var bid_amount = randomBetween(min: amount_min, max: amount_max)
            
            comp_move = (move:"bid", amount: bid_amount)
            print("comp played bid, amount \(bid_amount)")
            bid(player: player_num, amount: bid_amount)
        }
        if action == "fold"{
            // player is the winner
            print("computer folded")
            fold(player: 1)
        }
        
    }
    func randomBetween(min: Int, max: Int) -> Int {
        return Int.random(in: min...max)
    }
    

}
