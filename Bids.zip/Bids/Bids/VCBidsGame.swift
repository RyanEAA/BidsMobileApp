//
//  VCBidsGame.swift
//  Bids
//
//  Created by Turing on 10/2/24.
//

import UIKit

class VCBidsGame: UIViewController {
    
    
    @IBOutlet weak var imgPotMoney: UIImageView!
    
    var player_card: Card = Card(front_image: UIImage(named:"2_of_hearts")!, value:  (value_string:"2", value_int: 2), house: (house_string: "hearts", house_value:4))

    var comp_card: Card = Card(front_image: UIImage(named:"2_of_hearts")!, value:  (value_string:"2", value_int: 2), house: (house_string: "hearts", house_value:4))
    
    var comp_money = 15 {
        didSet {
            // check everytime comp_money changes
            checkPlayersMoney()
        }
    }
    
    // Player money
    var player_money: Int = 15 {
        didSet {
            // check everytime player_money changes
            checkPlayersMoney()
        }
    }
    
    // keep track of who's turn it is
    // 0 = player
    // 1 = comp
    var next_turn: Int = 0 {
        didSet {
            nextPlayer()
            checkPlayersMoney()
        }
    }
    
    var playOver: Bool = false {
        didSet {
            if playOver == true{
                revealCards()
                checkWin()
            }
        }
    }
    
    func nextPlayer(){
        print("next player = \(next_turn)")
        print("person completed move: \(player_completed_move)")
        // if the next turn is computer
        if next_turn == 1 && player_completed_move{
            player_completed_move = false
            print("computer is making a move")
            //grey out button options
            lowerAllButtonOpacity()
            
            // lower bid buttons
            lowerBidOpacity()
            
            next_turn = 0
            
            // the computer makes a move
            compMove()
            
            
        }
        // it's the computer's turn
        if next_turn == 0 {
            next_turn = 1
            increaseAllButtonOpacity()
            
        }
    }

    var pot_money = 0
    var player_move: (move: String, amount: Int) = (move:"", amount: 0)
    var comp_move: (move: String, amount: Int) = (move:"", amount: 0)
    var person_bid_amount = 0
    
    // is true when player completes move
    var player_completed_move = false

    // money label
    @IBOutlet weak var lblOppMoney: UILabel!
    @IBOutlet weak var lblMyMoney: UILabel!
    @IBOutlet weak var lblPotMoney: UILabel!
    
    @IBOutlet weak var btnBidDisplay: UIButton!
    @IBOutlet weak var btnFoldDisplay: UIButton!
    @IBOutlet weak var btnPassDisplay: UIButton!
    
    
    @IBOutlet weak var lblBidAmount: UILabel!
    @IBOutlet weak var sldrBidAmount: UISlider!
    
    
    
    @IBAction func btnPass(_ sender: Any) {
        if btnPassDisplay.alpha == 0.5{
            print("Pass cannot be pressed")
        } else {
            print("Pass Confirmed")
            // place bid here
            pass(player: 0)
            lowerBidOpacity()
            player_completed_move = true
        }
    }
    // bid slider
    @IBAction func sldrBidChanger(_ sender: Any) {
        var sldr_value = sldrBidAmount.value
        var bid_amount = Int(sldr_value) // Convert the result to Int if needed
        bid_amount = Int(bid_amount)
        person_bid_amount = bid_amount
        lblBidAmount.text = "Bid Amount: \(bid_amount)"
        updateLbls()
    }
    
    @IBOutlet weak var btnBidConfirmOpaq: UIButton!
    @IBAction func btnBidConfirm(_ sender: Any) {
        if btnBidConfirmOpaq.alpha == 0.5{
            print("cannot be pressed")
        } else {
            print("bid confirmed")
            // place bid here
            bid(player: 0, amount: person_bid_amount)
            print("player money amount: \(player_money)")
            print("comp money amount: \(comp_money)")
            lowerBidOpacity()
            player_completed_move = true
        }
    }
    
    // buttons for viable game actions
    @IBAction func btnBidMoney(_ sender: Any) {
        if btnBidDisplay.alpha == 0.5{
            print("im opaque")
        } else {
            lblBidAmount.text = String("Bid Amount: \(Int(sldrBidAmount.value))")
            // minimum bid has to be what opponent placed
            sldrBidAmount.minimumValue = Float(comp_move.amount)
            // max bid is what is in your amount
            sldrBidAmount.maximumValue = Float(player_money)
            
            print("min slider val: \(comp_move.amount), max slider val: \(player_money)")
            
            // sets initial amount
            sldrBidAmount.value = Float(comp_move.amount)
            print("Player Pressed Bid")
            lowerAllButtonOpacity()
            increaseBidOpacity()
        }
    }
    
    @IBAction func btnFold(_ sender: Any) {
        if btnFoldDisplay.alpha == 0.5{
            print("im opaque")
        } else {
            print("pressed fold")
            // logic for folding
            fold(player: 0)
            updateLbls()
            restartHandCardImages()
            lowerAllButtonOpacity()
            
        }
        player_completed_move = true
    }
    
    //deck image
    @IBOutlet weak var imgDeck: UIImageView!
    
    // players cards
    @IBOutlet weak var imgMyCard: UIImageView!
    @IBOutlet weak var imgCompCard: UIImageView!
    
    //holds the cards
    var cards_img_value_house: [Card] = []
    
    var robotsMove: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupGame()

    }
    
    func restartHandCardImages(){
        imgMyCard.image = UIImage(named:"click_deck")
        imgCompCard.image = UIImage(named:"board")
    }
    
    //handles tap gestures
    @objc func handleTap(_ sender: UITapGestureRecognizer){
        
        // is opponent card has been revealed
        if imgCompCard.image != UIImage(named: "back_red"){
            checkWin()
            
        }
        
        if let tappedImageView = sender.view as? UIImageView {
            
            if cards_img_value_house.count > 0 && imgMyCard.image == UIImage(named: "click_deck"){
                // gives the player a card
                getNewCards()
                
                increaseAllButtonOpacity()
                
                payCostOfPlaying()
                updateLbls()
                
//                print(player_card)
//                print(comp_card)
                                
            } else {
                print("cannot get cards from deck")
                
            }
        }
    }
    
    // randomises player and comp card
    func getNewCards(){
        print("\nEach Player Got New Cards")
        
        if imgMyCard.image == UIImage(named: "click_deck") {

            // you get a random card
            player_card = pickCard()
            
            // updates your card to new card
            self.imgMyCard.image = player_card.front_image
            
            // robots turn to pick a card
            print("it's the robots turn")
            
            
            comp_card = compPicksCard()
            
            // updates computer card img
            //current for testing
            //self.imgCompCard.image = comp_card.front_image
            
            //actual production
            self.imgCompCard.image = UIImage(named:"back_red")
            
            // updates stage_num
            
        }
        
        // if deck runs out of cards
        if cards_img_value_house.count <= 0{
            // pop up
            cardsRanOut()
        }
    }
    
    
// Override the touch handling method
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)

        // Get the location of the touch
        if let touch = touches.first {
            let touchLocation = touch.location(in: self.view)
            
            // Check if the touch location is NOT inside the UIImageView's frame
            if !btnBidConfirmOpaq.frame.contains(touchLocation) && btnBidConfirmOpaq.alpha == 1.0 {
                print("The player didn't confirm the bid")
                lowerBidOpacity()
                increaseAllButtonOpacity()
            }
            if btnBidConfirmOpaq.alpha == 1.0 && btnBidConfirmOpaq.frame.contains(touchLocation) {
                print("The player clicked the bid.")
            }
            
        }
    }

}


