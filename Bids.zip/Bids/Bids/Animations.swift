//
//  Animations.swift
//  Bids
//
//  Created by Ryan Aparicio on 10/4/24.
//

import Foundation
import UIKit

extension VCBidsGame{
    // updates labels
    func updateLbls(){
        lblMyMoney.text = ("Money: \(player_money)")
        lblOppMoney.text = ("Money: \(comp_money)")
        lblPotMoney.text = "Pot: \(pot_money)"
        
        if pot_money <= 0{
            imgPotMoney.image = UIImage(named:"board_color")
        } else {
            imgPotMoney.image = UIImage(named:"Screenshot 2024-10-02 at 10,05,50 PM")
        }
        
    }
    
    func revealCards() {
        let flipDuration = 0.5  // Duration of the flip

        // First half of the animation (flip to reveal the back)
        UIView.transition(with: imgCompCard, duration: flipDuration, options: .transitionFlipFromRight, animations: {
            // Toggle between card front and card back
            if self.imgCompCard.image == UIImage(named: "back_red") {
                self.imgCompCard.image = self.comp_card.front_image  // Show the front of the card
            } else {
                self.imgCompCard.image = UIImage(named: "back_red")  // Show the back of the card
            }
        }, completion: { _ in
            // After the first half, reveal the front image
            UIView.transition(with: self.imgCompCard, duration: flipDuration, options: .transitionFlipFromRight, animations: {
                self.imgCompCard.image = self.comp_card.front_image
                self.imgMyCard.image = self.player_card.front_image
            }) { _ in
                // Enable tap to choose a winner after cards are revealed
                self.enableTapToContinueWinner()
            }
        })
    }
    
    func enableTapToContinueWinner() {
        // This can be a flag or another method to indicate the user can now choose the winner
        print("Tap the screen to choose a winner!")
        lowerAllButtonOpacity()
        //winnerAnimation()

    }
    
    func winnerAnimation(){
        print("WOOOOOON")
        var resultImage: UIImage?
        resultImage = UIImage(named: "wins")
        // Show the result in a popup
        if let image = resultImage {
            showPopup(withImage: image)
        }
        
    }
    func lostAnimation(){
        print("LOOOOOST")
        var resultImage: UIImage?
        resultImage = UIImage(named: "lose")
        // Show the result in a popup
        if let image = resultImage {
            showPopup(withImage: image)
        }
    }
    
    func showPopup(withImage image: UIImage) {
        let popup = ImagePopupView(frame: self.view.bounds)
        popup.imageView.image = image
        self.view.addSubview(popup)
        
        // Optionally, you can add an animation for the popup
        popup.alpha = 0
        UIView.animate(withDuration: 0.3) {
            popup.alpha = 1
        }
    }

}
