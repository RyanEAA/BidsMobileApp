//
//  Misc.swift
//  Bids
//
//  Created by Ryan Aparicio on 9/26/24.
//

import Foundation
import UIKit



struct Card {
    let front_image: UIImage
    let value: (String, Int)
    let house: (String, Int)
}

func generateCardValues() -> [Card] {
    let cardValues = [ "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9, "10": 10, "jack": 11, "queen": 12, "king": 13, "ace": 14]
    let houses = ["spades": 4, "clubs": 1, "diamonds": 2, "hearts": 3]
    var listCardsValuesHouse: [Card] = []
    
    for (str, intValue) in cardValues {
        for (house, rank) in houses {
            // Appending tuple with the string format and corresponding int values
            let cardImage = UIImage(named:"\(str)_of_\(house)") ?? UIImage(named:"two_of_hearts")	
            listCardsValuesHouse.append(Card(front_image: cardImage!, value: (value_string: str, value_int: intValue), house: (house_string: house, house_int: rank)))

        }
    }
    
    listCardsValuesHouse.append(Card(front_image: UIImage(named:"joker_red")!, value:  (value_string: "joker", value_int: 15), house:(house_string: "joker", house_int:6)))
    listCardsValuesHouse.append(Card(front_image: UIImage(named:"joker_black")!, value:  (value_string: "joker", value_int: 15), house:(house_string: "joker", house_int:5)))
    
    return listCardsValuesHouse
}




