//
//  ImagePopUp.swift
//  Bids
//
//  Created by Turing on 10/4/24.
//

import Foundation
import UIKit

class ImagePopupView: UIView {
    
    var imageView: UIImageView!
    var continueButton: UIButton!

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupView()
    }
    
    private func setupView() {
        // Setup the background
        self.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        
        // ImageView setup
        imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(imageView)

        // Continue Button setup
        continueButton = UIButton(type: .system)
        continueButton.setTitle("Continue", for: .normal)
        continueButton.addTarget(self, action: #selector(continueGame), for: .touchUpInside)
        continueButton.translatesAutoresizingMaskIntoConstraints = false
        addSubview(continueButton)

        // Constraints for ImageView and Button
        NSLayoutConstraint.activate([
            imageView.centerXAnchor.constraint(equalTo: self.centerXAnchor),
            imageView.centerYAnchor.constraint(equalTo: self.centerYAnchor, constant: -20),
            imageView.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 0.8),
            imageView.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 0.5),

            continueButton.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 20),
            continueButton.centerXAnchor.constraint(equalTo: self.centerXAnchor)
        ])
    }

    @objc func continueGame() {
        self.removeFromSuperview() // Remove the popup from superview
    }
}

