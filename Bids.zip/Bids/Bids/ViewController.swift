//
//  ViewController.swift
//  Bids
//
//  Created by Ryan Aparicio on 9/26/24.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var imageView: UIImageView!
    

    // array of images
    var pickerView = UIPickerView()
    let viablePlayerCounts = ["1","2","3","4"]
    var cardStringValues = generateCardValues()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //one side of card
        imageView.image = UIImage(named:"back_red")
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(imageTapped))
        imageView?.isUserInteractionEnabled = true
        imageView?.addGestureRecognizer(tapGesture)
    }
    
    
    @objc func imageTapped() {
        flipImageView(imageView)
    }
    
    // pick random image from deck of cards

    func flipImageView(_ imageView: UIImageView) {
        
        let flipAnimations: [UIView.AnimationOptions]  = [.transitionFlipFromRight, .transitionFlipFromTop, .transitionFlipFromLeft, .transitionFlipFromBottom]
        
        let flipAnimationChoice = flipAnimations.randomElement()!
        
        
        
        // card card options
        let backCardList = ["back_red", "back_blue"]
        
        // check the current image and toggle it
        if imageView.image == UIImage(named:"back_red") || imageView.image == UIImage(named:"back_blue"){
            
            if let newFrontCard = cardStringValues.randomElement() {
                // Perform the flip animation
                UIView.transition(with: imageView, duration: 0.6, options: flipAnimationChoice, animations: {
                    imageView.image = newFrontCard.front_image
                }, completion: nil)
            } else {
                // Perform the flip animation
                UIView.transition(with: imageView, duration: 0.6, options: flipAnimationChoice, animations: {
                    imageView.image = UIImage(named: "two_of_hearts")
                }, completion: nil)
            }
            
        }
        else{
            let newBackCard = backCardList.randomElement()!
            UIView.transition(with: imageView, duration: 0.6, options: flipAnimationChoice, animations: {
                imageView.image = UIImage(named: newBackCard)
            }, completion: nil)
            
        }
    }
    
}


